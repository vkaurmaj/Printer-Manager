#include <stdio.h>
#include <string.h>

int main() {
    int x = 0;
    int i = 0;
    char * name = "Vahagn";

    for (i; i < strlen(name); i++) {
        x += name[i];
    }
    printf("Hello, %s! Welcome to ICS%d\n", name, 53);
    printf("%d\n", x);
    return 0;
}
